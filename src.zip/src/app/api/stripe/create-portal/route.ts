import { NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createClient } from '@/lib/supabase/server'

export async function POST() {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 401 })
    }

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: sub, error: subError } = await supabase
      .from('subscriptions')
      .select('stripe_customer_id')
      .eq('user_id', user.id)
      .maybeSingle()

    let customerId = sub?.stripe_customer_id || null

    // Fallback: recover Stripe customer by email if local subscription row is missing.
    if (!customerId && user.email) {
      const customers = await stripe.customers.list({
        email: user.email,
        limit: 10,
      })
      customerId = customers.data[0]?.id || null
    }

    if (subError || !customerId) {
      return NextResponse.json(
        { error: 'No billing profile found. Please subscribe first.' },
        { status: 400 }
      )
    }

    // Best effort local sync so future requests can use local data instantly.
    try {
      const stripeSubs = await stripe.subscriptions.list({
        customer: customerId,
        status: 'all',
        limit: 10,
      })

      const preferred =
        stripeSubs.data.find((s) => ['active', 'trialing', 'past_due', 'unpaid', 'incomplete'].includes(s.status)) ||
        stripeSubs.data[0]

      if (preferred) {
        const periodEndSeconds =
          typeof (preferred as any).current_period_end === 'number'
            ? (preferred as any).current_period_end
            : Math.floor(Date.now() / 1000)

        await supabase.from('subscriptions').upsert(
          {
            user_id: user.id,
            stripe_customer_id: customerId,
            stripe_subscription_id: preferred.id,
            status: preferred.status,
            plan: preferred.items.data[0]?.price?.id === process.env.STRIPE_PRICE_MONTHLY ? 'monthly' : 'yearly',
            current_period_end: new Date(periodEndSeconds * 1000).toISOString(),
          },
          { onConflict: 'stripe_customer_id' }
        )
      }
    } catch {
      // Ignore sync failures; billing portal can still open.
    }

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard`,
    })

    return NextResponse.json({ url: portalSession.url })
  } catch (error: any) {
    console.error('Billing portal error:', error)
    return NextResponse.json(
      { error: error?.message || 'Failed to open billing portal. Please try again.' },
      { status: 500 }
    )
  }
}
